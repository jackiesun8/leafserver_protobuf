local LayerBase=require("app.base.LayerBase")

local LayerBaseTest=class('LayerBaseTest',LayerBase)


function LayerBaseTest:ctor()
	self.super.ctor(self)
	self.layerType=1
end


function LayerBaseTest.create()	
    local obj=LayerBaseTest.new()
    obj:init()
    return obj
end


local function testfun(sender,event)
    print("btn click  aaa")
    if event==0 then
        print("btn click  0") --�����ť��������
    elseif event==1 then
        print("btn click  1") --�����ť��������
    elseif event==2 then
        print("btn click  2") --�����ť��������
    elseif event==3 then
        print("btn click  3") --�����ť��������
    end

end


function LayerBaseTest:init()
	print('LayerBaseTest init, type='..self.layerType)
	
    self.cslayer=cc.CSLoader:createNode("ui/MainScene.csb")
    self:addChild(self.cslayer)


    self.button=my.luaUtils:seekChildByName(self.cslayer,'Button_1')
    self.button:setScale(0.5)
    self.button:addTouchEventListener(testfun)
    
    local label=cc.Label:createWithSystemFont('fdfdd','Helvetica',26)
    self:addChild(label)
    

    
end



return LayerBaseTest