local sceneManager={}

SceneType=
{
    SceneType_None=0,
    SceneType_MainScene=1,
}
sceneManager.curScene=nil


function sceneManager:switchScene(type)
    local sceneTmp=nil;
    if type==SceneType.SceneType_MainScene then
    	sceneTmp=require("app.scene.mainScene"):create()
    elseif type==SceneType.SceneType_None then
    
    end
    if self.curScene==nil then
    	cc.Director:getInstance():runWithScene(sceneTmp)
    else
        cc.Director:getInstance():replaceScene(sceneTmp)
    end
    self.curScene=sceneTmp
    
end

return sceneManager