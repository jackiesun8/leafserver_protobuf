require 'person_pb'

local luaBridge={}

function protobufMsg(nMsgID,strMsg)  
    print("LUA PRINT,ID="..nMsgID)
    print("MSG:"..strMsg)  
    local msg = person_pb.Person()
    msg:ParseFromString(strMsg)
    dump(msg)
    local str=my.luaUtils:toUTF8(msg.name)
    return str  
end 


return luaBridge