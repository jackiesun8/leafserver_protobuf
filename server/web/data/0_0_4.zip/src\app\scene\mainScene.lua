
local testLayer=require("app.test.LayerBaseTest")
local sceneBase=require("app.base.sceneBase")

local mainScene=class("mainScene",sceneBase)


function mainScene:ctor()
    self.sceneType=1
    print('mainScene ctor')
end

function mainScene.create() 
    local obj=mainScene.new()
    obj:init()
    return obj
end

function mainScene:init()
    print('mainScene init,type='..self.sceneType)

    local layer=testLayer:create()
    self:addChild(layer)
end

return mainScene