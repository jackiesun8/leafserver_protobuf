

cc.FileUtils:getInstance():setPopupNotify(false)
cc.FileUtils:getInstance():addSearchPath("src/")
cc.FileUtils:getInstance():addSearchPath("res/")
cc.FileUtils:getInstance():addSearchPath("res/ui/")


require('luaBridge')
require "config"
require "cocos.init"
local sceneManager=require('app.scene.sceneManager')




local function main()
    local str=my.luaUtils:seekChildByName(cc.Layer:create(),"stsdf")
    local str2=my.luaUtils:toUTF8("stsdf")
    --sceneManager:switchScene(SceneType.SceneType_MainScene)
    --require("app.MyApp"):create():run()
    
end

local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
    print(msg)
end
