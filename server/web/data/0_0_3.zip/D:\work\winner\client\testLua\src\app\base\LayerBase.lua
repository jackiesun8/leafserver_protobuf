local LayerBase=class('LayerBase',function ()
	return cc.Layer:create()
end)

LayerBase.layerType=nil


function LayerBase:ctor()
	self.layerType=0
    print('LayerBase ctor')
end


function LayerBase:show(parent)
	if parent~=nil then
		parent:addChild(self)
	else
	   cc.Director:getInstance():getRunningScene():addChild(self)
	end
    print('LayerBase show')
end


return LayerBase