local sceneBase=class('sceneBase',function ()
    return cc.Scene:create()
end)

sceneBase.sceneType=nil


function sceneBase:ctor()
    self.sceneType=0
    print('sceneBase ctor')
end



return sceneBase